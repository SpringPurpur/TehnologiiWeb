const express = require('express')
const Book = require('./Book')
const app = express()
const port = 3000


const bookRouter = express.Router()

app.use(express.urlencoded({ extended: true }))
app.use(express.json())
app.use('/api', bookRouter)


let books = [new Book(1, "Dune", "sf", "Frank Herbert"),
new Book(2, "Robinson Crusoe", "adventure", "Daniel Defoe"),
new Book(3, "Foundation", "sf", "Asimov")]

bookRouter.route('/books')
    //Step 1 - GET request
    .get((req, res) => {
        let filteredBooks = [];
        if (req.query.genre) {
            filteredBooks = books.filter(x => x.genre === req.query.genre)
        }
        else {
            filteredBooks = books;
        }
        res.json(filteredBooks);
    })

    //Step 2 - POST request
    .post((req, res) => {
        let newBook = new Book(req.body.id, req.body.name, req.body.genre, req.body.author);

        books.push(newBook);
        console.log(books);
        return res.json(newBook);
    })

bookRouter.route('/validateBook')
    .post((req, res) => {
        let id = req.body.id;
        let name = req.body.name;
        let genre = req.body.genre;
        let author = req.body.author;

        if(id !== "") {
            if(!Number.isFinite(Number(id))) {
                return res.status(400).json({
                    code: "INVALID_ID",
                    message: "ID has to be a integer numeric value"
                });
            }
            if(Number(id) === books.find(b => b.id === Number(id)).id) {
                return res.status(400).json({
                code: "DUPLICATE_ID",
                message: "A book with this ID already exists"
            });
            }
        } else {
            return res.status(400).json({
                code: "INVALID_ID",
                message: "ID cannot be empty"
            });
        }

        if(name === "") {
            return res.status(400).json({
                code: "INVALID_NAME",
                message: "Name parameter cannot be empty"
            });
        }

        if(genre === "") {
            return res.status(400).json({
                code: "INVALID_GENRE",
                message: "Genre parameter cannot be empty"
            });
        }

        if(author === "") {
            return res.status(400).json({
                code: "INVALID_AUTHOR",
                message: "Author parameter cannot be empty"
            });
        }

        return res.status(200).json({message: "OK"});
    })

app.get('/', (req, res) => {
    res.send('Welcome to my API')
})

app.listen(port, () => {
    console.log('Running on the port ' + port)
})